/*! Copyright Disney. All rights reserved. */
/*jshint node:true*/
'use strict';

////////////////
/**
  *   @swagger
  *   /bonjour:
  *    get:
  *      tags:
  *      - "Bonjour"
  *      security:
  *      - lambda-authorizer: []
  *      description: "Bonjour"
  *      consumes:
  *      - application/json
  *      produces:
  *      - application/json
  *      parameters:
  *      - name: name
  *        in: query
  *        required: true
  *        type: string
  *      responses:
  *        200:
  *          description: "200 Response OK"
  *      x-amazon-apigateway-integration:
  *        responses:
  *          default:
  *            statusCode: '200'
  *        uri: $bonjour:LIGHT
  *        passthroughBehavior: when_no_templates
  *        httpMethod: POST
  *        requestTemplates:
  *          application/json: ''
  *        requestParameters:
  *        - integration.request.querystring.name: method.request.querystring.name
  *        type: aws_proxy
  */
exports.handler = function(event, context, callback) {
    var response = {
        statusCode: 200,
        headers: {
            'Content-Type': 'text/html; charset=utf-8'
        },
        body: getBody(event),
        isBase64Encoded: false
    };
    callback(null, response);
};

function getBody(event) {
  var name = '';
  if (event.name !== null && typeof event.name !== 'undefined' && event.name) {
    name = event.name;
  } else if (typeof event.queryStringParameters !== 'undefined' &&
      typeof event.queryStringParameters.name !== 'undefined' &&
      event.queryStringParameters.name) {
      name = event.queryStringParameters.name;
  } else if (typeof event.headers !== 'undefined' &&
      typeof event.headers.name !== 'undefined' &&
      event.headers.name) {
        name = event.headers.name;
  } else {
    name = 'World';
  }
	return 'Bonjour ' + name + '!';
}
